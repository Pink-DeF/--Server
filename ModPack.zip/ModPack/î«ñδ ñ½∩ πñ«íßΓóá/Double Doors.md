https://www.curseforge.com/minecraft/mc-mods/double-doors

Зависимости:
[[Collective]]