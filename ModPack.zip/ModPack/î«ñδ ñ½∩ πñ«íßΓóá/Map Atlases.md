https://www.curseforge.com/minecraft/mc-mods/map-atlases-forge

Зависимости:
[[Moonlight Lib]]