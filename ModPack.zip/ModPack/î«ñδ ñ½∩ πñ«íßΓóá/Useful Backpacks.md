https://www.curseforge.com/minecraft/mc-mods/useful-backpacks

Зависимости:
[[U Team Core]]