https://www.curseforge.com/minecraft/mc-mods/netherportalfix

Зависимости:
[[Balm]]