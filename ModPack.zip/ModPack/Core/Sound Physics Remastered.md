https://www.curseforge.com/minecraft/mc-mods/sound-physics-remastered

Мод для Minecraft, обеспечивающий реалистичное затухание звука, реверберацию и поглощение сквозь блоки.