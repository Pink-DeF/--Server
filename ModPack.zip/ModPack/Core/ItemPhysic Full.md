https://www.curseforge.com/minecraft/mc-mods/itemphysic

Зависимости:
[[CreativeCore]]