https://www.curseforge.com/minecraft/mc-mods/handcrafted

Зависимости:
[[Resourceful Lib]]
