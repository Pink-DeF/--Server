https://www.curseforge.com/minecraft/mc-mods/custom-credits

Зависимости:
[[Collective]]