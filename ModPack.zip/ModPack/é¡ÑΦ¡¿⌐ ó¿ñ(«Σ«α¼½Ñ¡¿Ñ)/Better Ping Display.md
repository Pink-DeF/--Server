https://www.curseforge.com/minecraft/mc-mods/better-ping-display

Мод для отображения пинга каждого игрока в списке игроков в виде числа.

