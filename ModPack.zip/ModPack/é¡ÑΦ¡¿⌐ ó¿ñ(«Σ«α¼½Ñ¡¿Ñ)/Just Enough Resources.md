https://www.curseforge.com/minecraft/mc-mods/just-enough-resources-jer

Самые последние сборки — это те, которые помечены как альфа (в основном, когда я что-то добавляю в репозиторий).

Зависимости:
[[JEI]]