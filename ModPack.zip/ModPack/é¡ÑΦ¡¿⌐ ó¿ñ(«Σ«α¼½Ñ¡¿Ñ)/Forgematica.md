https://www.curseforge.com/minecraft/mc-mods/forgematica

Зависимости:
[[MaFgLib]]