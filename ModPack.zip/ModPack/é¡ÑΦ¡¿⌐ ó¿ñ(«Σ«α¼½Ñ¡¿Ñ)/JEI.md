https://www.curseforge.com/minecraft/mc-mods/jei

JEI — это мод для просмотра предметов и рецептов для Minecraft, созданный с нуля для обеспечения стабильности и производительности.