https://www.curseforge.com/minecraft/mc-mods/betterf3

BetterF3 — это мод, который заменяет оригинальный отладочный HUD Minecraft на настраиваемый, более понятный человеку HUD. Вы можете настраивать цвета, положение, добавлять интервалы и многое другое.

Зависимость:
[[Cloth config API]]