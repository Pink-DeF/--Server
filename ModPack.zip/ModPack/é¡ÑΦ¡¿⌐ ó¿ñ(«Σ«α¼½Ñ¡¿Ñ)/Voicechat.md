https://www.curseforge.com/minecraft/mc-mods/simple-voice-chat

Голосовой чат для Minecraft с различными  [дополнениями](https://www.curseforge.com/linkout?remoteUrl=https%253a%252f%252fmodrepo.de%252fminecraft%252fvoicechat%252faddons)  , предлагающими дополнительные функции и возможности.

Зависимости:
[[Cloth config API]]
[[Sound Physics Remastered]]