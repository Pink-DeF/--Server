https://www.curseforge.com/minecraft/mc-mods/just-enough-professions-jep

Этот мод добавляет новую функциональность в [**JEI**](https://www.curseforge.com/minecraft/mc-mods/jei) . Эта новая функциональность позволяет пользователю определять, какие рабочие столы требуются для каждой профессии жителя деревни.

Зависимости:
[[JEI]]