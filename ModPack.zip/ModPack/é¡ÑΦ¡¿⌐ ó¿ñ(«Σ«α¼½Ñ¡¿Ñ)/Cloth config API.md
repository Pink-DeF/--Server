https://www.curseforge.com/minecraft/mc-mods/cloth-config

Cloth Config API — это API экрана конфигурации.