https://www.curseforge.com/minecraft/mc-mods/dynamic-fps

Уменьшите потребление ресурсов, когда Minecraft работает в фоновом режиме, бездействует или работает от батареи.

Зависимости:
[[Cloth config API]]