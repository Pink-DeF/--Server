https://www.curseforge.com/minecraft/mc-mods/kotlin-for-forge
https://www.curseforge.com/minecraft/mc-mods/kotlinlangforge

Зависимости:
[[Inline]]
[[PAUCAL]]
[[Caelus API]]