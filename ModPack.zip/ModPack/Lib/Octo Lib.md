https://www.curseforge.com/minecraft/mc-mods/octo-lib

Коллекция общего кода для  модов [**OctoStudios**](https://www.curseforge.com/linkout?remoteUrl=https%253a%252f%252focto-studios.com%252f) . Список реализованных на данный момент функций:

- Конфигурация на основе YAML, подобная Datapack, с автоматической проверкой, глубокой сериализацией и другими функциями безопасности.