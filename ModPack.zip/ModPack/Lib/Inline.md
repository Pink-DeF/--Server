https://www.curseforge.com/minecraft/mc-mods/inline

Зависимости:
[[Cloth config API]]