https://www.curseforge.com/minecraft/mc-mods/relics-mod

Зависимости:
[[Curios API]]
[[Octo Lib]]