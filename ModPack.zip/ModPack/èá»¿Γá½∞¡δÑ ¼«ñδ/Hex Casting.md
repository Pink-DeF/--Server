https://www.curseforge.com/minecraft/mc-mods/hexcasting

Зависимости:
[[Kotlin for Forge]]