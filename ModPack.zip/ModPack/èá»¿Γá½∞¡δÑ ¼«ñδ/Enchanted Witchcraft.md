https://www.curseforge.com/minecraft/mc-mods/enchanted-witchcraft

Зависимости:
[[GeckoLib]]
[[SmartBrainLib]]
[[StateObserver]]