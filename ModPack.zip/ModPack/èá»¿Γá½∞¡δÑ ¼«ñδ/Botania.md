https://www.curseforge.com/minecraft/mc-mods/botania

Зависимости:
[[Curios API]]
[[Patchouli]]